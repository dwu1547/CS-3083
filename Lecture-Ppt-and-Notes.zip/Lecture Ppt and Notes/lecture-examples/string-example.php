<!DOCTYPE html>

<?php

$variable = "hello";

//double quotes
echo "Value in double quotes is $variable.";

echo "<br /><br />";

//single quotes
echo 'Value in single quotes is $variable.';

?>