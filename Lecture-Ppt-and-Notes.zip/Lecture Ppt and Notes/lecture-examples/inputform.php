<!DOCTYPE html>

<html>
<body>

<form action = "findinfo.php" method="GET">
Choose a person<br>
<select name='XX'>

<?php

include "connectdb.php";

if ($stmt = $mysqli->prepare("select XX from XX")) {
  $stmt->execute();
  $stmt->bind_result($XX);
  while($stmt->fetch()) {
	$XX = htmlspecialchars($XX);
	echo "<option value='$XX'>$XX</option>\n";	
  }
  $stmt->close();
  $mysqli->close();
}

?>
	
</select><input type = "submit" value = "Find Fun Fact ">
</form>
</body>
</html>
