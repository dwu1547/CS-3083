<!DOCTYPE html>

<html>
<body>

<form action = "get-input-example.php" method="GET">
Choose a topic<br>
<select name='topic'>

<?php

include "connectdb.php";

if ($stmt = $mysqli->prepare("select distinct topic from book")) {
  $stmt->execute();
  $stmt->bind_result($topic);
  while($stmt->fetch()) {
	$topic = htmlspecialchars($topic);
	echo "<option value='$topic'>$topic</option>\n";	
  }
  $stmt->close();
  $mysqli->close();
}

?>
	
	</select><input type = "submit" value = "Show books">
</form>
</body>
</html>
