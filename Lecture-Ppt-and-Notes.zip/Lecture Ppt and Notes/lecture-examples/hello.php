<!DOCTYPE html>

<html>
<head>
  <title>Hello, world</title>
</head>
<body bgcolor="#ffffff">
  <h1>
  <?php
    print "Hello, world";
  ?>
  </h1>
</body>
</html>
