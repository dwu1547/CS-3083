<!DOCTYPE html>

<html>
<body>

<form action = "get-input-example.php" method="GET">
Choose a topic<br>
<select name='topic'>

	<option value='Cooking'>Cooking</option>
	<option value='Science Fiction'>Science Fiction</option>
	<option value='Childrens'>Childrens</option>
	<option value='Classic'>Classic</option>
	<option value='Novel'>Novel</option>

	</select><input type = "submit" value = "Show books">
</form>
</body>
</html>