
--
-- Table structure for table `book`
--

CREATE TABLE IF NOT EXISTS `book` (
  `isbn` decimal(10,0) PRIMARY KEY,
  `title` varchar(300) default NULL,
  `topic` varchar(40) default NULL,
  `base_price` decimal(6,2) default NULL,
  `current_price` decimal(6,2) default NULL,
  `num_in_stock` int(11) default NULL
);
--
-- Dumping data for table `book`
--

INSERT INTO `book` 
(isbn, title, topic, base_price, current_price, num_in_stock)
VALUES
(1111111111, 'Claires Corner Copia Cookbook', 'Cooking', 25.00, 13.39, 15),
(2222222222, 'Madhur Jaffrey Indian Cooking', 'Cooking', 29.99, 19.79, 43),
(3333333333, 'American Gods: A Novel', 'Science Fiction', 14.95, 10.17, 65),
(4444444444, 'Dance Dance Dance', 'Science Fiction', 14.95, 10.17, 69),
(5555555555, 'A Wild Sheep Chase', 'Science Fiction', 14.95, 10.17, 66),
(6666666666, 'Curious George', 'Childrens', 10.00, 8.00, 16),
(7777777777, 'The Cat in the Hat', 'Childrens', 8.99, 8.99, 659),
(8888888888, 'Marvin K. Mooney Will You Please Go Now!', 'Childrens', 8.99, 8.99, 83),
(9999999999, 'The Great Gatsby', 'Classic', 13.95, 11.16, 290),
(1234567890, 'Slaughterhouse-Five', 'Novel', 14.00, 11.20, 162);

