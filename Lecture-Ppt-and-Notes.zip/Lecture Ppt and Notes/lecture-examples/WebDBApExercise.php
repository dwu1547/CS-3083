<!DOCTYPE html>
// exercise:
// create a database, put some data in it, think of a query,
// then fill in the XX's to get input from the user's http request,
// bind it to the query, execute the query, and format the results into an html table
// execute it from your browser, typing the parameter name/value into the address bar

// For example, using the University DB,
// you could find the name and ID of all instructors in a particluar department
// Try to think of something more interesting.

// If you have time when you finish, write another script that presents an interface
// for the user to enter the parameter, then calls this script as an action.

<html>
<?php

include "connectdb.php"; // you might need to edit this with your DB userID and password

//set up SQL query
if(isset($_GET["XX"])) {
    $input_id = $_GET["XX"];
    if ($stmt = $mysqli->prepare("XX WHERE id=?")) {
        $stmt->bind_param("X", $XX);

        // execute query
        $stmt->execute();
        $stmt->bind_result(XX);

        // Printing results in HTML
        echo "<table border = '1'>\n";
        while ($stmt->fetch()) {
	        echo "<tr>";
                echo "<td>XX</td> XX </td>";
	        echo "</tr>\n";
        }
        echo "</table>\n";
        $stmt->close();
	$mysqli->close();
    }
}
else {
    echo "XX is not set\n";
}
?>
</html>
