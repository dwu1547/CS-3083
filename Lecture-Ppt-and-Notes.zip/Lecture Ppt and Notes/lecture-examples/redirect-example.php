<!DOCTYPE html>
<?php
// header function must be called before any output
// header("location: http://www.poly.edu"); -- redirect without pause
header("refresh:5; http://www.poly.edu"); // redirect after 5 second pause
echo "You will be redirected in 5 seconds. ";
echo "If not, click <a href=\"http://engineering.nyu.edu\">here</a>.";
?>
