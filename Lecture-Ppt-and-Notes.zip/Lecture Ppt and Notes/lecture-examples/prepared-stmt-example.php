<!DOCTYPE html>

<html>
<?php

include "connectdb.php";

    $input_topic = 'Childrens';

//create SQL query
    if ($stmt = $mysqli->prepare("SELECT * FROM book WHERE topic=?")) {
        $stmt->bind_param("s", $input_topic);
//execute SQL query
        $stmt->execute();
        $stmt->bind_result($isbn, $title, $topic, $base_price, $current_price, $num_in_stock);

        // Printing results in HTML
        echo "<table border = '1'>\n";
        while ($stmt->fetch()) {
	        echo "<tr>";
            echo "<td>$isbn</td><td>$title</td><td>$topic</td><td>$base_price</td><td>$current_price</td><td>$num_in_stock</td>";
	        echo "</tr>\n";
        }
        echo "</table>\n";
        $stmt->close();
	$mysqli->close();
    }
?>
</html>
