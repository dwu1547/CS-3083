<!DOCTYPE html>

<html>
<?php

include "connectdb.php";

//perform SQL query
if(isset($_GET["topic"])) {
    $input_topic = $_GET["topic"];
    if ($stmt = $mysqli->prepare("SELECT * FROM book WHERE topic=?")) {
        $stmt->bind_param("s", $input_topic);
        $stmt->execute();
        $stmt->bind_result($isbn, $title, $topic, $base_price, $current_price, $num_in_stock);

        // Printing results in HTML
        echo "<table border = '1'>\n";
        while ($stmt->fetch()) {
	        echo "<tr>";
            echo "<td>$isbn</td><td>$title</td><td>$topic</td><td>$base_price</td><td>$current_price</td><td>$num_in_stock</td>";
	        echo "</tr>\n";
        }
        echo "</table>\n";
        $stmt->close();
	$mysqli->close();
    }
}
else {
    echo "topic is not set\n";
}
?>
</html>
